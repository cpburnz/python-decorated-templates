Change History
==============

0.7.6 (2012-08-30)
------------------

 - Add "CHANGES.rst"
 - Fix indentation error.
 

0.7.5 (2012-08-30)
------------------

 - Fix class instance methods.
 - Fix class ``@classmethod`` methods.
 - Fix class ``@staticmethod`` methods.
 - Fix file line in tracebacks.


0.7.4 (2012-08-29)
------------------

 - Support class functions.
 - Fix file name in tracebacks.


0.7.3 (2012-08-29)
------------------

 - Update "README.rst".


0.7.2 (2012-08-29)
------------------

 - Fix "README.rst".


0.7.1 (2012-08-29)
------------------

 - Add "README.rst".
 

0.7 (2012-08-23)
------------------

 - Initial release.
